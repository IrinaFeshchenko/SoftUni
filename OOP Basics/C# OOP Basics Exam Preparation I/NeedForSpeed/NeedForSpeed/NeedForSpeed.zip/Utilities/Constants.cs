﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Constants
{
    public const string INPUT_TERMINATING_COMMAND = "End";
    public const int MAX_PERCENTAGE = 100;
    public const int PERFOROMANCE_CAR_HOREPOWER_INCREASE_PERCENTAGE = 50;
    public const int PERFORMANCE_CAR_SUSPENSION_DECREASE_PERCENTAGE = 25;
}
