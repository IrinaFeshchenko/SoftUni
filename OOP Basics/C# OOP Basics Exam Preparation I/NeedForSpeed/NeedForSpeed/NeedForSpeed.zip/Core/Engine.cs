﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Engine
{
    public void Run()
    {
        string s = Console.ReadLine();
        Console.WriteLine(s);
    }
}
