﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Garage
{
    //todo: modify parked cars ?

    //o	Has parkedCars (Collection of Cars).
    private List<Car> parkedCars;

    public Garage()
    {
        this.parkedCars = new List<Car>();
    }

    public List<Car> ParkedCars
    {
        get { return parkedCars; }
    }
}
