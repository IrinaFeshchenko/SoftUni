﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class DragRace : Race
{
    public DragRace(int length, int route, int prizePool) 
        : base(length, route, prizePool)
    {
    }
}
