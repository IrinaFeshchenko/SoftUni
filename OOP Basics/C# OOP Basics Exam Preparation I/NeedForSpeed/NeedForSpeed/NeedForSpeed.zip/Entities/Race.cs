﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public abstract class Race
{
    //length(int), 
    private int length;
    //route(string), 
    private int route;
    //a prizePool(int), 
    private int prizePool;
    //and participants(Collection of Cars)
    private List<Car> participants;

    public Race(int length, int route, int prizePool)
    {
        this.Length = length;
        this.Route = route;
        this.PrizePool = prizePool;
    }

    public int Length
    {
        get { return length; }
        set { length = value; }
    }

    public int Route
    {
        get { return route; }
        set { route = value; }
    }

    public int PrizePool
    {
        get { return prizePool; }
        set { prizePool = value; }
    }

    public List<Car> Participants
    {
        get { return participants; }
    }
}
