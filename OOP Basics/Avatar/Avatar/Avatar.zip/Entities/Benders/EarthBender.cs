﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class EarthBender:Bender
{
    //The EarthBender has an additional characteristic:
    //•	GroundSaturation – a floating-point number, holding the groundSaturation of the Bender.
    private double groundSaturation;

    public double GroundSaturation
    {
        get { return groundSaturation; }
        set { groundSaturation = value; }
    }

}
