﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class WaterBender:Bender
{
    //The WaterBender has an additional characteristic:
    //•	WaterClarity – a floating-point number, holding the waterClarity of the Bender.
    private double waterClarity;

    public double WaterClarity
    {
        get { return waterClarity; }
        set { waterClarity = value; }
    }

}
