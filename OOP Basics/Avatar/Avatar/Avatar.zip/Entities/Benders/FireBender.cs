﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class FireBender: Bender
{
    //The FireBender has an additional characteristic:
    //•	HeatAggression – a floating-point number, holding the heatAggression of the Bender.
    private double heatAggression;

    public double HeatAggression
    {
        get { return heatAggression; }
        set { heatAggression = value; }
    }

}
