﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public abstract class Monument
{
    //•	Name – a string, holding the name of the Monument.
    private string name;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }
}
