﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class EarthMonument:Monument
{
    //•	EarthAffinity – an integer, holding the earthAffinity of the Monument.
    private int earthAffinity;

    public int EarthAffinity
    {
        get { return earthAffinity; }
        set { earthAffinity = value; }
    }

}
