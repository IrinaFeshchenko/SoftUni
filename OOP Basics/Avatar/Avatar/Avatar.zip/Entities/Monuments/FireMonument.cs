﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class FireMonument:Monument
{
    //•	FireAffinity – an integer, holding the fireAffinity of the Monument.
    private int fireAffinity;

    public int FireAffinity
    {
        get { return fireAffinity; }
        set { fireAffinity = value; }
    }

}
