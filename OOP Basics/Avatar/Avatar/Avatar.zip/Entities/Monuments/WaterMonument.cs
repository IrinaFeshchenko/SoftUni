﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class WaterMonument:Monument
{
    //•	WaterAffinity – an integer, holding the waterAffinity of the Monument.
    private int waterAffinity;

    public int WaterAffinity
    {
        get { return waterAffinity; }
        set { waterAffinity = value; }
    }

}
